# village_object > 2025-03-02 1:57pm
https://universe.roboflow.com/custom-yolo-3cnvc/village_object

Provided by a Roboflow user
License: CC BY 4.0

