# My_group > 2025-02-25 10:43pm
https://universe.roboflow.com/custom-yolo-3cnvc/my_group

Provided by a Roboflow user
License: CC BY 4.0

